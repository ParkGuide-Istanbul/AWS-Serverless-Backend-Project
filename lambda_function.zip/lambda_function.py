import json
import boto3
import jwt
import datetime
from botocore.exceptions import ClientError

# DynamoDB ayarları
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Users')

# JWT için gizli anahtar (güvenli bir şekilde saklanmalı)
SECRET_KEY = 'Q56WTH4D98N1J2D5Z6U1UTKLDI4J5D6F'

def lambda_handler(event, context):
    # Kullanıcı adı ve şifresi API Gateway'den alınır
    body = json.loads(event['body'])
    username = body['username']
    password = body['password']

    # Kullanıcı bilgilerini DynamoDB'den kontrol et
    try:
        response = table.get_item(Key={'Username': username})
    except ClientError as e:
        print(e.response['Error']['Message'])
        return {'statusCode': 500, 'body': json.dumps('Internal serer error: User not found')}

    # Kullanıcı bulunursa ve şifre doğruysa JWT oluştur
    if 'Item' in response and response['Item']['Password'] == password:
        # Token içeriği
        payload = {
            'username': username,
            'roles': list(response['Item']['Roles']),
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=3)
        }
        # JWT oluştur
        token = jwt.encode(payload, SECRET_KEY, algorithm='HS256')
        print("token: " + token)
        print("\n")
        decoded_payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        print("Decoded JWT Payload:")
        print(decoded_payload)
        return {
            'statusCode': 200,
            'body': json.dumps({'token': token})
        }
    else:
        return {'statusCode': 402, 'body': json.dumps('Wrong password')}

# Test için
event = {
    'body': '{"username": "alpbeydemir", "password": "samplepassword"}'
}
lambda_handler(event, None)